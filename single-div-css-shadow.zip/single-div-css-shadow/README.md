# Single div CSS shadow

A Pen created on CodePen.io. Original URL: [https://codepen.io/lynnandtonic/pen/yLjZYxe](https://codepen.io/lynnandtonic/pen/yLjZYxe).

\#divtober Day 12: Shadow 🔦 [a.singlediv.com](https://a.singlediv.com)